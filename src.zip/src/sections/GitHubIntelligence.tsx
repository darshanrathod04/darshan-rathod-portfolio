import { motion } from "framer-motion";
import {
  GitBranch,
  GitCommit,
  GithubLogo,
  Star,
  Code,
  ClockCountdown,
  ArrowSquareOut,
} from "@phosphor-icons/react";

const stats = [
  { icon: GitBranch, label: "Repositories", value: "14+" },
  { icon: GitCommit, label: "Commits", value: "500+" },
  { icon: Star, label: "Flagship Projects", value: "04" },
  { icon: Code, label: "Primary Stack", value: "Java" },
];

const repos = [
  {
    name: "Shree-AI-OS",
    desc: "Autonomous AI Operating System for intelligent software engineering.",
    lang: "Java",
    color: "bg-orange-400",
    status: "ACTIVE",
    link: "https://github.com/darshanrathod04",
  },
  {
    name: "Smart-Campus-Connect",
    desc: "Student · College · Company ecosystem with Spring Boot architecture.",
    lang: "Spring Boot",
    color: "bg-emerald-400",
    status: "PRODUCTION",
    link: "https://github.com/darshanrathod04",
  },
  {
    name: "EduFlow-360",
    desc: "Living academic intelligence with modern React frontend.",
    lang: "React",
    color: "bg-cyan-400",
    status: "LIVE",
    link: "https://github.com/darshanrathod04",
  },
  {
    name: "Library-Management",
    desc: "REST API + MySQL backend architecture.",
    lang: "Java",
    color: "bg-orange-400",
    status: "COMPLETED",
    link: "https://github.com/darshanrathod04",
  },
];

const cells = Array.from({ length: 364 }).map((_, i) => ({
  id: i,
  level: Math.floor(Math.random() * 5),
}));

export default function GitHubIntelligence() {
  return (
    <section
      id="github"
      className="relative overflow-hidden border-t border-white/10 bg-[#030712] py-32"
    >
      {/* Background Glow */}
      <div className="absolute right-0 top-0 h-[500px] w-[500px] rounded-full bg-cyan-500/10 blur-[140px]" />
      <div className="absolute left-0 bottom-0 h-[420px] w-[420px] rounded-full bg-violet-500/10 blur-[130px]" />

      <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="mb-4 flex items-center gap-3">
            <GithubLogo size={18} className="text-cyan-300" />
            <span className="font-mono text-xs uppercase tracking-[0.35em] text-cyan-300">
              GitHub Intelligence
            </span>
          </div>

          <h2 className="text-5xl font-black leading-none text-white md:text-7xl">
            Engineering
            <br />
            <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-transparent">
              Activity
            </span>
          </h2>

          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-400">
            Continuous backend engineering, AI platform development and scalable
            software architecture built through disciplined Git workflows.
          </p>
        </motion.div>

        {/* Stats */}
        <div className="mb-12 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((item, i) => {
            const Icon = item.icon;

            return (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                viewport={{ once: true }}
                className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur-xl"
              >
                <Icon size={26} className="mb-4 text-cyan-300" />

                <div className="text-3xl font-black text-white">
                  {item.value}
                </div>

                <div className="mt-1 text-sm text-slate-400">
                  {item.label}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Heatmap */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mb-14 rounded-[32px] border border-white/10 bg-white/[0.04] p-8 backdrop-blur-2xl"
        >
          <div className="mb-6 flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">
              Contribution Heatmap
            </h3>

            <div className="flex items-center gap-2 text-xs text-slate-500">
              Less
              {[0, 1, 2, 3, 4].map((l) => (
                <div
                  key={l}
                  className={`h-3 w-3 rounded-sm ${
                    l === 0
                      ? "bg-[#161B22]"
                      : l === 1
                      ? "bg-cyan-900"
                      : l === 2
                      ? "bg-cyan-700"
                      : l === 3
                      ? "bg-cyan-500"
                      : "bg-cyan-300"
                  }`}
                />
              ))}
              More
            </div>
          </div>

          <div className="grid grid-cols-28 gap-1">
            {cells.map((cell) => (
              <motion.div
                key={cell.id}
                whileHover={{ scale: 1.8 }}
                className={`aspect-square rounded-[2px] ${
                  cell.level === 0
                    ? "bg-[#161B22]"
                    : cell.level === 1
                    ? "bg-cyan-900"
                    : cell.level === 2
                    ? "bg-cyan-700"
                    : cell.level === 3
                    ? "bg-cyan-500"
                    : "bg-cyan-300"
                }`}
              />
            ))}
          </div>

          <div className="mt-6 flex items-center gap-2 text-sm text-slate-400">
            <ClockCountdown size={16} className="text-cyan-300" />
            Continuous engineering and learning journey
          </div>
        </motion.div>

        {/* Repository Cards */}
        <div className="grid gap-6 lg:grid-cols-2">
          {repos.map((repo, i) => (
            <motion.a
              href={repo.link}
              target="_blank"
              rel="noreferrer"
              key={repo.name}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              viewport={{ once: true }}
              className="group rounded-3xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur-xl transition hover:-translate-y-1 hover:border-cyan-400/30"
            >
              <div className="mb-5 flex items-center justify-between">
                <GithubLogo
                  size={24}
                  className="text-slate-500 transition group-hover:text-cyan-300"
                />

                <span className="rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1 text-xs text-cyan-300">
                  {repo.status}
                </span>
              </div>

              <h3 className="text-2xl font-bold text-white">
                {repo.name}
              </h3>

              <p className="mt-3 leading-7 text-slate-400">
                {repo.desc}
              </p>

              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <div className={`h-3 w-3 rounded-full ${repo.color}`} />
                  <span className="text-slate-300">{repo.lang}</span>
                </div>

                <ArrowSquareOut
                  size={20}
                  className="text-cyan-300 opacity-0 transition group-hover:opacity-100"
                />
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}