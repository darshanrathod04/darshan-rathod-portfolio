import { motion } from "framer-motion";
import {
  Atom,
  Database,
  GitBranch,
  Cpu,
  Globe,
  Stack,
  Brain,
  Cloud,
} from "@phosphor-icons/react";

const skills = [
  { icon: Cpu, name: "Java", x: 0, y: -180 },
  { icon: Stack, name: "Spring", x: 130, y: -90 },
  { icon: Globe, name: "React", x: 180, y: 30 },
  { icon: Database, name: "MySQL", x: 130, y: 150 },
  { icon: GitBranch, name: "Git", x: -130, y: 150 },
  { icon: Brain, name: "AI", x: -180, y: 20 },
  { icon: Cloud, name: "REST", x: -130, y: -90 },
];

export default function SkillsGalaxy() {
  return (
    <section
      id="skills"
      className="relative border-t border-white/10 py-32 overflow-hidden"
    >
      <div className="mx-auto max-w-6xl px-6 text-center">
        <p className="font-mono text-xs tracking-[0.35em] text-cyan-300 uppercase">
          TECHNOLOGY GALAXY
        </p>

        <h2 className="mt-4 text-5xl md:text-7xl font-black text-white">
          Skills Orbiting
          <span className="block bg-gradient-to-r from-cyan-300 to-violet-400 bg-clip-text text-transparent">
            One Intelligence Core
          </span>
        </h2>

        <div className="relative mx-auto mt-24 h-[520px] w-[520px]">
          {[160, 240, 320].map((r) => (
            <motion.div
              key={r}
              animate={{ rotate: 360 }}
              transition={{
                repeat: Infinity,
                duration: r / 4,
                ease: "linear",
              }}
              className="absolute left-1/2 top-1/2 rounded-full border border-cyan-400/10"
              style={{
                width: r,
                height: r,
                marginLeft: -r / 2,
                marginTop: -r / 2,
              }}
            />
          ))}

          <motion.div
            animate={{
              scale: [1, 1.08, 1],
              boxShadow: [
                "0 0 30px rgba(34,211,238,.3)",
                "0 0 70px rgba(139,92,246,.45)",
                "0 0 30px rgba(34,211,238,.3)",
              ],
            }}
            transition={{ repeat: Infinity, duration: 4 }}
            className="absolute left-1/2 top-1/2 flex h-36 w-36 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-cyan-400/30 bg-gradient-to-br from-cyan-500/20 to-violet-500/20 backdrop-blur-xl"
          >
            <div>
              <Atom
                size={36}
                weight="duotone"
                className="mx-auto text-cyan-300"
              />
              <div className="mt-2 text-xl font-black text-white">
                SHREE
              </div>
            </div>
          </motion.div>

          {skills.map((skill, i) => {
            const Icon = skill.icon;

            return (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                animate={{ y: [0, -8, 0] }}
                transition={{
                  delay: i * 0.08,
                  repeat: Infinity,
                  duration: 3 + i * 0.3,
                }}
                className="absolute left-1/2 top-1/2"
                style={{
                  transform: `translate(${skill.x}px, ${skill.y}px)`,
                }}
              >
                <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-4 backdrop-blur-xl">
                  <Icon
                    size={28}
                    weight="duotone"
                    className="mx-auto text-cyan-300"
                  />
                  <p className="mt-2 text-sm text-white font-medium">
                    {skill.name}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}