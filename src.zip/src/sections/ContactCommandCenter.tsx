import { motion } from "framer-motion";
import {
  ArrowUpRight,
  EnvelopeSimple,
  GithubLogo,
  LinkedinLogo,
  MapPin,
  PaperPlaneTilt,
  Phone,
} from "@phosphor-icons/react";

export default function ContactCommandCenter() {
  return (
    <section
      id="contact"
      className="relative overflow-hidden border-t border-white/10 bg-[#030712] py-28"
    >
      {/* Background Glow */}
      <div className="absolute left-0 top-0 h-[420px] w-[420px] rounded-full bg-cyan-500/10 blur-[140px]" />
      <div className="absolute bottom-0 right-0 h-[320px] w-[320px] rounded-full bg-violet-500/10 blur-[120px]" />

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <span className="font-mono text-xs tracking-[0.35em] text-cyan-300">
            CONTACT COMMAND CENTER
          </span>

          <h2 className="mt-5 text-5xl font-black md:text-7xl">
            Let's Build
            <br />
            <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-transparent">
              Something Exceptional
            </span>
          </h2>

          <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-400">
            Open for Java Full Stack internships, backend engineering roles and
            ambitious software collaborations.
          </p>
        </motion.div>

        <div className="grid gap-8 lg:grid-cols-[1.05fr_.95fr]">
          {/* LEFT PANEL */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="rounded-[30px] border border-white/10 bg-white/[0.03] p-8 backdrop-blur-2xl"
          >
            <h3 className="text-2xl font-bold text-white">
              Direct Communication
            </h3>

            <p className="mt-3 leading-7 text-slate-400">
              I usually respond within 24 hours. The fastest way to reach me is
              through email or LinkedIn.
            </p>

            <div className="mt-10 space-y-5">
              <InfoCard
                icon={<EnvelopeSimple size={22} weight="duotone" />}
                title="Email"
                value="darshanmrathod.2005@gmail.com"
                href="mailto:darshanmrathod.2005@gmail.com"
              />

              <InfoCard
                icon={<LinkedinLogo size={22} weight="duotone" />}
                title="LinkedIn"
                value="Darshan Rathod"
                href="https://www.linkedin.com/in/darshan-rathod-fullstack-developer/"
              />

              <InfoCard
                icon={<GithubLogo size={22} weight="duotone" />}
                title="GitHub"
                value="github.com/darshanrathod04"
                href="https://github.com/darshanrathod04"
              />

              <InfoCard
                icon={<MapPin size={22} weight="duotone" />}
                title="Location"
                value="Nagpur, Maharashtra, India"
              />
            </div>

            <div className="mt-10 rounded-2xl border border-cyan-400/20 bg-cyan-400/5 p-5">
              <p className="font-mono text-xs tracking-[0.28em] text-cyan-300">
                CURRENT STATUS
              </p>

              <div className="mt-4 flex items-center gap-3">
                <div className="h-3 w-3 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-semibold text-white">
                  Available for Internship & Full-Time Opportunities
                </span>
              </div>
            </div>
          </motion.div>

          {/* RIGHT PANEL */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="rounded-[30px] border border-white/10 bg-white/[0.03] p-8 backdrop-blur-2xl"
          >
            <h3 className="mb-8 text-2xl font-bold text-white">
              Quick Message
            </h3>

            <div className="space-y-5">
              <Input label="Your Name" placeholder="Darshan Rathod" />
              <Input
                label="Email Address"
                placeholder="you@example.com"
                type="email"
              />
              <Input
                label="Subject"
                placeholder="Internship Opportunity"
              />

              <div>
                <label className="mb-2 block text-sm text-slate-400">
                  Message
                </label>

                <textarea
                  rows={6}
                  placeholder="Tell me about your project or opportunity..."
                  className="w-full resize-none rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 text-white outline-none transition focus:border-cyan-400/40"
                />
              </div>

              <button className="group flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-500 to-violet-500 py-4 font-bold text-black transition hover:scale-[1.02]">
                <PaperPlaneTilt size={22} weight="fill" />
                Send Message
                <ArrowUpRight
                  size={18}
                  className="transition group-hover:-translate-y-1 group-hover:translate-x-1"
                />
              </button>
            </div>

            <div className="mt-8 flex items-center justify-center gap-6 border-t border-white/10 pt-6">
              <SocialButton
                icon={<GithubLogo size={24} weight="fill" />}
                href="https://github.com/darshanrathod04"
              />

              <SocialButton
                icon={<LinkedinLogo size={24} weight="fill" />}
                href="https://www.linkedin.com/in/darshan-rathod-fullstack-developer/"
              />

              <SocialButton
                icon={<EnvelopeSimple size={24} weight="fill" />}
                href="mailto:darshanmrathod.2005@gmail.com"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Components ---------- */

function Input({
  label,
  placeholder,
  type = "text",
}: {
  label: string;
  placeholder: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-slate-400">{label}</label>

      <input
        type={type}
        placeholder={placeholder}
        className="w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 text-white outline-none transition focus:border-cyan-400/40"
      />
    </div>
  );
}

function InfoCard({
  icon,
  title,
  value,
  href,
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  href?: string;
}) {
  const content = (
    <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-cyan-400/30">
      <div className="rounded-xl bg-cyan-400/10 p-3 text-cyan-300">
        {icon}
      </div>

      <div className="min-w-0">
        <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
          {title}
        </p>

        <p className="truncate font-medium text-white">{value}</p>
      </div>
    </div>
  );

  if (href) {
    return (
      <a href={href} target="_blank" rel="noreferrer">
        {content}
      </a>
    );
  }

  return content;
}

function SocialButton({
  icon,
  href,
}: {
  icon: React.ReactNode;
  href: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="rounded-xl border border-white/10 bg-white/[0.03] p-3 text-slate-300 transition hover:border-cyan-400/30 hover:text-cyan-300"
    >
      {icon}
    </a>
  );
}