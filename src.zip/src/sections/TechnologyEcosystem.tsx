import { motion } from "framer-motion";
import {
  Cpu,
  Database,
  Shield,
  Brain,
  Boxes,
  Cloud,
} from "lucide-react";

const nodes = [
  { icon: Cpu, label: "Spring Boot", angle: 0 },
  { icon: Database, label: "MySQL", angle: 60 },
  { icon: Shield, label: "Security", angle: 120 },
  { icon: Brain, label: "AI Systems", angle: 180 },
  { icon: Boxes, label: "REST APIs", angle: 240 },
  { icon: Cloud, label: "Cloud Ready", angle: 300 },
];

export default function TechnologyEcosystem() {
  return (
    <section
      id="stack"
      className="relative overflow-hidden border-t border-white/10 bg-[#030712] py-32"
    >
      {/* Background Glow */}
      <div className="absolute left-1/2 top-20 h-[700px] w-[700px] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-[160px]" />

      {/* Grid */}
      <div
        className="absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px)
          `,
          backgroundSize: "48px 48px",
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20 text-center"
        >
          <p className="font-mono text-xs tracking-[0.35em] text-cyan-300">
            ENGINEERING ECOSYSTEM
          </p>

          <h2 className="mt-5 text-5xl font-black leading-none text-white md:text-7xl">
            Intelligence
            <br />
            <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-transparent">
              Technology Orbit
            </span>
          </h2>

          <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-400">
            Every system I build revolves around scalable architecture,
            security-first backend engineering and intelligent software design.
          </p>
        </motion.div>

        {/* Orbit */}
        <div className="flex justify-center">
          <div className="relative h-[620px] w-[620px]">
            {/* Orbit Rings */}
            {[1, 2, 3].map((ring) => (
              <motion.div
                key={ring}
                animate={{ rotate: ring % 2 === 0 ? -360 : 360 }}
                transition={{
                  repeat: Infinity,
                  duration: 45 + ring * 15,
                  ease: "linear",
                }}
                className="absolute inset-0 rounded-full border border-cyan-400/10"
                style={{
                  scale: 0.45 + ring * 0.22,
                }}
              />
            ))}

            {/* Center Core */}
            <motion.div
              animate={{
                scale: [1, 1.06, 1],
                boxShadow: [
                  "0 0 40px rgba(34,211,238,.35)",
                  "0 0 90px rgba(139,92,246,.45)",
                  "0 0 40px rgba(34,211,238,.35)",
                ],
              }}
              transition={{
                repeat: Infinity,
                duration: 4,
              }}
              className="absolute left-1/2 top-1/2 flex h-44 w-44 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-cyan-400/30 bg-gradient-to-br from-cyan-500/20 to-violet-500/20 backdrop-blur-xl"
            >
              <div className="text-center">
                <div className="text-xs tracking-[0.25em] text-cyan-300">
                  CORE
                </div>

                <div className="mt-2 text-3xl font-black text-white">
                  SHREE
                </div>

                <div className="text-sm text-slate-400">AI • Backend</div>
              </div>
            </motion.div>

            {/* Orbit Nodes */}
            {nodes.map((node, i) => {
              const radius = 235;
              const rad = (node.angle * Math.PI) / 180;

              const x = Math.cos(rad) * radius;
              const y = Math.sin(rad) * radius;

              const Icon = node.icon;

              return (
                <motion.div
                  key={node.label}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.08 }}
                  viewport={{ once: true }}
                  animate={{
                    y: [0, -8, 0],
                  }}
                  className="absolute left-1/2 top-1/2"
                  style={{
                    x,
                    y,
                  }}
                >
                  <div className="group w-36 -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-white/10 bg-white/[0.04] p-4 backdrop-blur-xl transition hover:border-cyan-400/40">
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-400/10 text-cyan-300">
                      <Icon size={22} />
                    </div>

                    <p className="mt-3 text-center text-sm font-semibold text-white">
                      {node.label}
                    </p>
                  </div>
                </motion.div>
              );
            })}

            {/* Center Pulse */}
            <motion.div
              animate={{
                scale: [1, 2.2],
                opacity: [0.35, 0],
              }}
              transition={{
                repeat: Infinity,
                duration: 2.5,
              }}
              className="absolute left-1/2 top-1/2 h-44 w-44 -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-400/30"
            />
          </div>
        </div>

        {/* Bottom Stats */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 grid gap-5 md:grid-cols-4"
        >
          {[
            ["Java", "Primary Language"],
            ["Spring Boot", "Backend Framework"],
            ["REST + JWT", "API Architecture"],
            ["AI Systems", "Future Platform"],
          ].map(([title, sub]) => (
            <div
              key={title}
              className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl"
            >
              <h3 className="text-xl font-bold text-white">{title}</h3>
              <p className="mt-2 text-sm text-slate-400">{sub}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}