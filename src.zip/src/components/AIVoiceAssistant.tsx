import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Microphone,
  SpeakerHigh,
  X,
  Brain,
} from "@phosphor-icons/react";

const replies = {
  projects:
    "Darshan has built Smart Campus Connect, EduFlow 360, Library Management and Shree AI OS.",
  skills:
    "Primary stack includes Java, Spring Boot, REST APIs, MySQL, React and AI Engineering.",
  contact:
    "You can contact Darshan through LinkedIn, GitHub or the Contact Command Center below.",
  default:
    "I'm your AI portfolio assistant. Ask about projects, skills or experience.",
};

export default function AIVoiceAssistant() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [reply, setReply] = useState(replies.default);
  const [listening, setListening] = useState(false);

  const SpeechRecognition = useMemo(
    () =>
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition,
    []
  );

  const speak = (msg: string) => {
    const utter = new SpeechSynthesisUtterance(msg);
    utter.rate = 1;
    utter.pitch = 1;
    speechSynthesis.cancel();
    speechSynthesis.speak(utter);
  };

  const ask = (value: string) => {
    const q = value.toLowerCase();

    let ans = replies.default;

    if (q.includes("project")) ans = replies.projects;
    else if (q.includes("skill")) ans = replies.skills;
    else if (q.includes("contact")) ans = replies.contact;

    setReply(ans);
    speak(ans);
  };

  const startVoice = () => {
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();

    setListening(true);

    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setText(transcript);
      ask(transcript);
      setListening(false);
    };

    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);
  };

  useEffect(() => {
    return () => speechSynthesis.cancel();
  }, []);

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(true)}
        className="fixed bottom-8 right-8 z-[80] h-16 w-16 rounded-full border border-cyan-400/30 bg-black/60 backdrop-blur-xl"
      >
        <Brain size={30} className="mx-auto text-cyan-300" />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-28 right-8 z-[90] w-[360px] rounded-3xl border border-cyan-400/20 bg-[#07111f]/95 p-6 backdrop-blur-2xl"
          >
            <div className="mb-5 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white">Shree AI</h3>
                <p className="text-xs text-cyan-300">
                  Portfolio Intelligence
                </p>
              </div>

              <button onClick={() => setOpen(false)}>
                <X size={18} className="text-slate-400" />
              </button>
            </div>

            <div className="mb-4 rounded-2xl bg-white/5 p-4 text-sm leading-7 text-slate-300">
              {reply}
            </div>

            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ask about projects..."
              className="mb-4 w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none"
            />

            <div className="flex gap-3">
              <button
                onClick={() => ask(text)}
                className="flex-1 rounded-xl bg-cyan-400 py-3 font-semibold text-black"
              >
                Ask
              </button>

              <button
                onClick={startVoice}
                className={`rounded-xl border px-4 ${
                  listening
                    ? "border-red-400 text-red-300"
                    : "border-white/10 text-white"
                }`}
              >
                <Microphone size={22} />
              </button>

              <button
                onClick={() => speak(reply)}
                className="rounded-xl border border-white/10 px-4 text-white"
              >
                <SpeakerHigh size={22} />
              </button>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {["Projects", "Skills", "Contact"].map((q) => (
                <button
                  key={q}
                  onClick={() => {
                    setText(q);
                    ask(q);
                  }}
                  className="rounded-full border border-cyan-400/20 px-3 py-1 text-xs text-cyan-300"
                >
                  {q}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}