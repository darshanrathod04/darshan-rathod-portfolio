import { motion } from "framer-motion";
import {
  Database,
  ShieldCheck,
  Cpu,
  Code,
  Globe,
  CheckCircle,
  GitBranch,
  Stack,
} from "@phosphor-icons/react";

const endpoints = [
  { method: "POST", path: "/api/auth/login", color: "emerald" },
  { method: "GET", path: "/api/students", color: "cyan" },
  { method: "POST", path: "/api/applications", color: "violet" },
  { method: "GET", path: "/api/events", color: "orange" },
];

const metrics = [
  { label: "REST APIs", value: "28+", icon: Globe },
  { label: "Tables", value: "14", icon: Database },
  { label: "Security", value: "JWT", icon: ShieldCheck },
  { label: "Pattern", value: "MVC", icon: GitBranch },
];

export default function DeveloperConsole() {
  return (
    <motion.div
      initial={{ opacity: 0, rotateX: 8, y: 40 }}
      animate={{ opacity: 1, rotateX: 0, y: 0 }}
      transition={{ duration: 0.9 }}
      className="relative"
      style={{ perspective: 1800 }}
    >
      {/* Ambient Glow */}
      <div className="absolute -inset-8 rounded-[40px] bg-cyan-500/10 blur-[90px]" />

      <div className="relative overflow-hidden rounded-[30px] border border-white/10 bg-[#050816]/95 backdrop-blur-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-red-400" />
            <div className="h-3 w-3 rounded-full bg-yellow-400" />
            <div className="h-3 w-3 rounded-full bg-green-400" />
          </div>

          <div className="flex items-center gap-2 text-cyan-300">
            <Code size={16} weight="duotone" />
            <span className="font-mono text-xs tracking-[0.3em]">
              BACKEND.CONSOLE
            </span>
          </div>

          <div className="flex items-center gap-2 text-emerald-300">
            <CheckCircle size={16} weight="fill" />
            <span className="text-xs">READY</span>
          </div>
        </div>

        <div className="p-6">
          {/* Architecture Card */}
          <motion.div
            animate={{
              boxShadow: [
                "0 0 0 rgba(34,211,238,0)",
                "0 0 30px rgba(34,211,238,.15)",
                "0 0 0 rgba(34,211,238,0)",
              ],
            }}
            transition={{ repeat: Infinity, duration: 4 }}
            className="mb-6 rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-5"
          >
            <div className="mb-3 flex items-center gap-2">
              <Stack size={18} className="text-cyan-300" />
              <span className="text-xs tracking-[0.25em] text-cyan-300">
                PRODUCTION ARCHITECTURE
              </span>
            </div>

            <h3 className="text-2xl font-black text-white">
              Spring Boot Backend
            </h3>

            <p className="mt-2 text-sm text-slate-300">
              Java • React • MySQL • JWT Authentication
            </p>
          </motion.div>

          {/* API Endpoints */}
          <div className="mb-6 rounded-2xl border border-white/10 bg-black/25 p-4">
            <div className="mb-4 flex items-center justify-between">
              <span className="font-mono text-xs tracking-[0.2em] text-slate-400">
                REGISTERED ENDPOINTS
              </span>

              <span className="text-xs text-cyan-300">28 APIs</span>
            </div>

            <div className="space-y-3">
              {endpoints.map((ep, i) => (
                <motion.div
                  key={ep.path}
                  initial={{ opacity: 0, x: -15 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.15 }}
                  className="flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`rounded px-2 py-1 text-[10px] font-bold ${
                        ep.color === "emerald"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : ep.color === "cyan"
                          ? "bg-cyan-500/20 text-cyan-300"
                          : ep.color === "violet"
                          ? "bg-violet-500/20 text-violet-300"
                          : "bg-orange-500/20 text-orange-300"
                      }`}
                    >
                      {ep.method}
                    </span>

                    <span className="font-mono text-sm text-slate-300">
                      {ep.path}
                    </span>
                  </div>

                  <CheckCircle
                    size={16}
                    weight="fill"
                    className="text-emerald-300"
                  />
                </motion.div>
              ))}
            </div>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-2 gap-3">
            {metrics.map((item) => {
              const Icon = item.icon;

              return (
                <motion.div
                  whileHover={{ y: -4 }}
                  key={item.label}
                  className="rounded-xl border border-white/10 bg-white/[0.03] p-4"
                >
                  <Icon
                    size={22}
                    weight="duotone"
                    className="mb-3 text-cyan-300"
                  />

                  <div className="text-xl font-black text-white">
                    {item.value}
                  </div>

                  <div className="mt-1 text-xs text-slate-500">
                    {item.label}
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Architecture Flow */}
          <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-xs tracking-[0.2em] text-slate-400">
                REQUEST FLOW
              </span>

              <span className="text-xs text-cyan-300">
                MVC Pattern
              </span>
            </div>

            <div className="flex items-center justify-between text-center">
              {[
                "React",
                "REST",
                "Service",
                "MySQL",
              ].map((step, i) => (
                <div
                  key={step}
                  className="flex flex-1 items-center"
                >
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-400/10 text-xs font-bold text-cyan-300">
                    {step}
                  </div>

                  {i !== 3 && (
                    <div className="mx-2 h-px flex-1 bg-gradient-to-r from-cyan-400/40 to-transparent" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4 text-xs text-slate-500">
            <span>Backend Engineer Workspace</span>

            <span className="text-cyan-300">
              Spring Boot 4 Ready
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}