export interface Project {
  id: number;
  number: string;
  title: string;
  tagline: string;
  description: string;
  category: string;
  status: string;
  image: string;
  featured: boolean;
  technologies: string[];
  github?: string;
  demo?: string;
}

export const projects: Project[] = [
  {
    id: 1,
    number: "01",
    title: "Smart Campus Connect",
    tagline:
      "Student • College • Company Collaboration Platform",
    description:
      "A full stack platform connecting students, colleges and companies through role-based authentication, applications, events, internships and scalable REST APIs. Built with clean MVC architecture and production-oriented backend design.",
    category: "FULL STACK PLATFORM",
    status: "FLAGSHIP PROJECT",
    image: "/projects/smart-campus-connect.png",
    featured: true,
    technologies: [
      "Java",
      "Spring Boot",
      "React",
      "TypeScript",
      "JWT",
      "MySQL",
    ],
    github: "https://github.com/darshanrathod04",
  },

  {
    id: 2,
    number: "02",
    title: "EduFlow 360",
    tagline: "Living Academic Intelligence Dashboard",
    description:
      "Modern educational analytics dashboard featuring student progress tracking, performance visualization, reusable UI components and responsive frontend engineering.",
    category: "FRONTEND ENGINEERING",
    status: "LIVE PROJECT",
    image: "/projects/eduflow-360.png",
    featured: true,
    technologies: [
      "React",
      "TypeScript",
      "Tailwind CSS",
      "Charts",
    ],
    github: "https://github.com/darshanrathod04",
    demo: "https://eduflow-360.netlify.app",
  },

  {
    id: 3,
    number: "03",
    title: "Library Management System",
    tagline: "REST API + Database Architecture",
    description:
      "Backend-focused Java application implementing CRUD operations, MySQL integration, repository pattern and scalable REST services with clean project structure.",
    category: "BACKEND SYSTEM",
    status: "COMPLETED",
    image: "/projects/library-management.png",
    featured: true,
    technologies: [
      "Java",
      "Spring Boot",
      "REST API",
      "MySQL",
    ],
    github: "https://github.com/darshanrathod04",
  },

  {
    id: 4,
    number: "04",
    title: "Authentication Service",
    tagline: "JWT Security Module",
    description:
      "Reusable authentication module demonstrating login, registration, JWT token generation, authorization filters and role-based access control.",
    category: "BACKEND MODULE",
    status: "MODULE",
    image: "/projects/auth-service.png",
    featured: false,
    technologies: [
      "Spring Security",
      "JWT",
      "Java",
    ],
    github: "https://github.com/darshanrathod04",
  },

  {
    id: 5,
    number: "05",
    title: "REST API Architecture",
    tagline: "Scalable Service Layer Design",
    description:
      "Reference backend architecture showcasing controller, service, repository and entity separation following Spring Boot best practices.",
    category: "ARCHITECTURE",
    status: "REFERENCE",
    image: "/projects/rest-api.png",
    featured: false,
    technologies: [
      "Spring Boot",
      "MVC",
      "Repository Pattern",
    ],
    github: "https://github.com/darshanrathod04",
  },

  {
    id: 6,
    number: "06",
    title: "Student Dashboard UI",
    tagline: "Responsive Component System",
    description:
      "Reusable dashboard interface designed with React, TypeScript and modular components optimized for educational applications.",
    category: "UI SYSTEM",
    status: "DESIGN SYSTEM",
    image: "/projects/dashboard-ui.png",
    featured: false,
    technologies: [
      "React",
      "TypeScript",
      "Tailwind",
    ],
    github: "https://github.com/darshanrathod04",
  },
];